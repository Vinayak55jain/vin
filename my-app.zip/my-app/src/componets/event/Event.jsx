import React, { useState } from 'react';
import './Event.css';
import EventList from './EventList';
import EventDetail from './EventDetail';

const events = [
  {
    name: 'Event 1',
    intro: 'loreumbvhbhvbsjbvjkv snbhvbhbhvbhjbhh jhjhjhhjh jj h j j j h jh s',
    subEvents: [
      { ev1: 'Sub Event 1.1', detail1: 'Short heading 1.1', detail2: 'Loreum 1.1', img1: '#' },
      'Sub Event 1.2',
      'Sub Event 1.3'
    ],
  },
  {
    name: 'Event 2',
    intro: 'Introduction to Event 2',
    subEvents: [
      'Sub Event 2.1',
      'Sub Event 2.2'
    ],
  },
  {
    name: 'Event 3',
    intro: 'Introduction to Event 3',
    subEvents: [
      'Sub Event 3.1',
      'Sub Event 3.2',
      'Sub Event 3.3'
    ],
  },
];

const Event = () => {
  const [selectedEvent, setSelectedEvent] = useState(null);

  return (
    <div className="app-container">
      <div className={`event-list-container ${selectedEvent ? 'hide-on-small-screen' : ''}`}>
        <EventList events={events} onSelectEvent={setSelectedEvent} />
      </div>
      <div className={`event-detail-container ${selectedEvent ? '' : 'hide-on-small-screen'}`}>
        <EventDetail event={selectedEvent} />
      </div>
    </div>
  );
};

export default Event;
