import React from 'react';
import './Style.css'
import Example from './Tilt';
import { FlatTree } from 'framer-motion';

const Gallery =()=>{
    return(
        <div style={{backgroundColor:'none'}}>

        <h1>GALLERY</h1>
        <div className='body' >
            <Example></Example>
            <Example></Example>
            <Example></Example>
            <Example></Example>
 
       </div>
       </div>
    );
}
export default Gallery;